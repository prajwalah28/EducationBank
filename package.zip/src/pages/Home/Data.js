import { Icons } from "../../assets/assets";

export const Data = [
  {
    img: Icons.c1,
    title: "Teach your way",
    desc: "Teach what you know and help learners explore their interests, gain new skills, and advance their careers.",
  },
  {
    img: Icons.c2,
    title: "Teach your way",
    desc: "Teach what you know and help learners explore their interests, gain new skills, and advance their careers.",
  },
  {
    img: Icons.c3,
    title: "Teach your way",
    desc: "Teach what you know and help learners explore their interests, gain new skills, and advance their careers.",
  },
];
