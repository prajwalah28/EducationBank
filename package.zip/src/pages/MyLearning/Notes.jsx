import React from 'react'

export default function Notes() {
  return (
    <div>
    <h1 className='text-2xl font-bold text-center mt-4'>Your Notes</h1>
    <div className='flex py-6 items-center gap-12 mt-12 mx-auto w-1/2'>
    <h1 className='text-2xl font-bold'>1]</h1>
      <h1 className='text-2xl font-bold'>Java Complete Notes.pdf</h1>
      <div className=''><a href='https://drive.google.com/file/d/1TWL1lmCNzKOy7RHTlvtB1Eu5I182H7BU/view?usp=sharing' className='bg-orange-500 py-3 px-10 text-white rounded-md font-bold'>Download</a></div>
    </div>
    </div>
  )
}
