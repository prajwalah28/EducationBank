import React from 'react'

const QandA = () => {
  return (
    <div>QandA</div>
  )
}

export default QandA