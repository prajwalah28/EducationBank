import img1 from "../../assets/images/Untitled (559 x 273 px).png";
import img2 from "../../assets/images/Untitled (559 x 273 px) (1).png";
import img3 from "../../assets/images/3.png";
import img4 from "../../assets/images/4.png";
import img5 from "../../assets/images/mern.jpg";

const Courses = [
  {
    id: 1,
    image: img1,
    name: "React Course",
    price: 200
  },
  {
    id: 2,
    image: img2,
    name: "Node.js Course",
    price: 300
  },
  {
    id: 3,
    image: img3,
    name: "JavaScript Basics",
    price: 400
  },
  {
    id: 4,
    image: img4,
    name: "JavaScript Advanced",
    price: 500
  },
  {
    id: 5,
    image: img4,
    name: "MERN Stack Course",
    price: 600
  },
  {
    id: 6,
    image: img3,
    name: "React Native Course",
    price: 700
  }
];

export default Courses;
