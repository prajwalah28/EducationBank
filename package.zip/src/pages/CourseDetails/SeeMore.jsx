import React from 'react'

const SeeMore
 = () => {
  return (
    <div>
        <div className='flex flex-row justify-center gap-8 text-xl mt-16 mb-6'>
        
        <div className='flex flex-col gap-8'>
            <div className='flex flex-row gap-2'>
                <div className='mt-1'><TiTick size={24}/></div>
                <div>You will learn how to leverages the power of <br/> Python to solve tasks.</div>
            </div>

            <div className='flex flex-row gap-2'>
                <div className='mt-1'><TiTick size={24} /></div>
                <div>You will learn how to leverages the power of <br/> Python to solve tasks.</div>
            </div>

            <div className='flex flex-row gap-2'>
                <div className='mt-1'><TiTick size={24} /></div>
                <div>You will learn how to leverages the power of <br/> Python to solve tasks.</div>
            </div>

                
        </div>

        <div className='flex flex-col gap-8'>
            <div className='flex flex-row gap-2'>
                <div className='mt-1'><TiTick size={24} /></div>
                <div>You will learn how to leverages the power of <br/> Python to solve tasks.</div>
            </div>

            <div className='flex flex-row gap-2'>
                <div className='mt-1'><TiTick size={24} /></div>
                <div>You will learn how to leverages the power of <br/> Python to solve tasks.</div>
            </div>

            <div className='flex flex-row gap-2'>
                <div className='mt-1'><TiTick size={24} /></div>
                <div>You will learn how to leverages the power of <br/> Python to solve tasks.</div>
            </div>
        </div>
    </div>
    </div>
  )
}

export default SeeMore;
