
export const RatingData = [
    {
      name:"Sanket" ,
      dayago:"1 day ago",
      desc: "Teach what you know and help learners explore their interests, gain new skills, and advance their careers.",
    },
    {
      name:"prajwal" ,
      dayago:"1 day ago",
      desc: "Teach what you know and help learners explore their interests, gain new skills, and advance their careers.",
    },
    {
      name:"Abhishek" ,
      dayago:"1 day ago",
      desc: "Teach what you know and help learners explore their interests, gain new skills, and advance their careers.",
    },
    {
      name:"Sarthak" ,
      dayago:"1 day ago",
      desc: "Teach what you know and help learners explore their interests, gain new skills, and advance their careers.",
    }
  ];